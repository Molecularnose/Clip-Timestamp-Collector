
import React, { useState, useEffect } from 'react';
import { Session, TimestampMark } from '../types';

interface ViewerModeProps {
  sessionId: string;
}

const QUICK_TAGS = ['🔥 EPIC', '😂 FUNNY', '💀 RIP', '😲 CLUTCH', '🏆 WIN'];

const ViewerMode: React.FC<ViewerModeProps> = ({ sessionId }) => {
  const [session, setSession] = useState<Session | null>(null);
  const [note, setNote] = useState('');
  const [username, setUsername] = useState(localStorage.getItem('cc_username') || '');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const sessions: Session[] = JSON.parse(localStorage.getItem('cc_sessions') || '[]');
    const current = sessions.find(s => s.id === sessionId);
    if (current) {
      setSession(current);
    } else {
      setError('Session link invalid or expired.');
    }
  }, [sessionId]);

  const handleSubmit = (overrideNote?: string) => {
    if (!session || submitted) return;

    setIsSubmitting(true);
    if (username) localStorage.setItem('cc_username', username);

    const now = new Date();
    const start = new Date(session.startTime);
    // Calculate offset relative to stream start
    const offsetSeconds = Math.max(0, Math.floor((now.getTime() - start.getTime()) / 1000));

    const finalNote = overrideNote || note;

    const newMark: TimestampMark = {
      id: Math.random().toString(36).substr(2, 9),
      sessionId: session.id,
      offsetSeconds,
      note: finalNote.slice(0, 100),
      submittedBy: username || 'Anonymous',
      isClipped: false,
      createdAt: now.toISOString(),
    };

    const marks = JSON.parse(localStorage.getItem('cc_marks') || '[]');
    localStorage.setItem('cc_marks', JSON.stringify([...marks, newMark]));

    // Visual feedback delay
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
      setNote('');
      // Allow new submissions after a short cooldown
      setTimeout(() => setSubmitted(false), 2000);
    }, 200);
  };

  if (error) return <div className="text-center text-red-500 py-32 font-black tracking-widest uppercase px-4">{error}</div>;
  if (!session) return <div className="text-center py-32 text-slate-700 animate-pulse font-black uppercase tracking-[0.3em]">Connecting to session...</div>;

  return (
    <div className="flex flex-col gap-8 max-w-lg mx-auto py-4 px-2 animate-in fade-in slide-in-from-bottom-8 duration-700">
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-red-500/10 text-red-500 text-[10px] font-black rounded-full border border-red-500/20">
          <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
          LIVE SESSION
        </div>
        <h2 className="text-2xl font-black tracking-tighter">{session.title}</h2>
        <p className="text-slate-500 text-xs font-bold uppercase tracking-widest">{session.game}</p>
      </div>

      <div className="relative group">
        {!submitted && (
          <div className="absolute inset-0 bg-orange-500/10 blur-[60px] rounded-full scale-110 opacity-50 group-hover:opacity-100 transition-all animate-pulse" />
        )}
        
        <div className="relative bg-slate-900/80 backdrop-blur-md p-8 rounded-[3.5rem] border border-slate-800 shadow-2xl flex flex-col gap-8 items-center text-center overflow-hidden min-h-[500px] justify-center">
          {submitted && (
            <div className="absolute inset-0 bg-green-500/5 flex flex-col items-center justify-center animate-in fade-in zoom-in duration-300 z-20">
              <div className="text-green-500 font-black text-xs uppercase tracking-[0.3em] bg-slate-950 px-6 py-2 rounded-full border border-green-500/30 shadow-2xl mb-4">
                Moment Saved!
              </div>
              <div className="text-6xl">✅</div>
            </div>
          )}

          <button
            onClick={() => handleSubmit()}
            disabled={isSubmitting || submitted}
            className={`
              w-48 h-48 rounded-full text-8xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] transition-all duration-500 transform
              relative flex items-center justify-center select-none
              ${submitted 
                ? 'bg-green-600 scale-90 opacity-0' 
                : 'bg-gradient-to-br from-orange-400 to-red-600 hover:scale-105 active:scale-90 shadow-orange-900/50'
              }
              ${isSubmitting ? 'scale-75 opacity-50' : ''}
            `}
          >
            <span className="relative z-10">🔥</span>
          </button>
          
          <div className={`transition-all duration-500 ${submitted ? 'opacity-0 translate-y-4' : 'opacity-100'}`}>
            <p className="text-xl font-black uppercase tracking-tighter text-white mb-2">
              Tap to Mark Clip
            </p>
            <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest">
              Seconds are synced to the stream start
            </p>
          </div>

          <div className={`w-full space-y-6 transition-all duration-500 pt-4 ${submitted ? 'opacity-0 pointer-events-none scale-95' : 'opacity-100'}`}>
            <div className="flex flex-wrap justify-center gap-2">
              {QUICK_TAGS.map(tag => (
                <button
                  key={tag}
                  disabled={submitted || isSubmitting}
                  onClick={() => handleSubmit(tag)}
                  className="bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-full px-4 py-2 text-[10px] font-black text-slate-500 hover:text-white transition-all active:scale-95"
                >
                  {tag}
                </button>
              ))}
            </div>

            <div className="space-y-4 pt-4">
              <div className="space-y-2 text-left">
                <label className="text-[10px] uppercase font-black text-slate-600 ml-2 tracking-widest">Username (Optional)</label>
                <input
                  type="text"
                  placeholder="Anonymous"
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-5 py-3 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-orange-500/30 transition-all text-slate-200"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                />
              </div>
              <div className="space-y-2 text-left">
                <label className="text-[10px] uppercase font-black text-slate-600 ml-2 tracking-widest">Optional Note</label>
                <textarea
                  placeholder="What happened?"
                  maxLength={100}
                  rows={2}
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-5 py-3 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-orange-500/30 transition-all resize-none text-slate-200"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="text-center pt-4">
        <p className="text-[10px] text-slate-700 font-black uppercase tracking-[0.2em]">
          Clip Collector • Community Powered
        </p>
      </div>
    </div>
  );
};

export default ViewerMode;
