
import React, { useState, useEffect } from 'react';
import { Session } from '../types';

const Home: React.FC = () => {
  const [title, setTitle] = useState('');
  const [game, setGame] = useState('');
  const [startTime, setStartTime] = useState('');
  const [recentSessions, setRecentSessions] = useState<Session[]>([]);

  useEffect(() => {
    // Default start time to now
    const now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    setStartTime(now.toISOString().slice(0, 16));

    const sessions = JSON.parse(localStorage.getItem('cc_sessions') || '[]');
    setRecentSessions(sessions.reverse());
  }, []);

  const handleCreateSession = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !game) return;

    const newSession: Session = {
      id: Math.random().toString(36).substr(2, 9),
      title,
      game,
      startTime: new Date(startTime).toISOString(),
      createdAt: new Date().toISOString(),
    };

    const sessions = JSON.parse(localStorage.getItem('cc_sessions') || '[]');
    localStorage.setItem('cc_sessions', JSON.stringify([...sessions, newSession]));

    window.location.hash = `#/d/${newSession.id}`;
  };

  const deleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm('This will permanently delete the session and all marks. Proceed?')) return;
    
    const sessions: Session[] = JSON.parse(localStorage.getItem('cc_sessions') || '[]');
    const filtered = sessions.filter(s => s.id !== id);
    localStorage.setItem('cc_sessions', JSON.stringify(filtered));
    setRecentSessions(filtered.slice().reverse());

    const marks = JSON.parse(localStorage.getItem('cc_marks') || '[]');
    localStorage.setItem('cc_marks', JSON.stringify(marks.filter((m: any) => m.sessionId !== id)));
  };

  const setTimeToNow = () => {
    const now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    setStartTime(now.toISOString().slice(0, 16));
  };

  return (
    <div className="flex flex-col gap-12 max-w-2xl mx-auto py-4 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="text-center space-y-4">
        <div className="inline-block px-4 py-1 bg-orange-500/10 border border-orange-500/20 rounded-full">
          <span className="text-[10px] font-black uppercase tracking-[0.3em] text-orange-500">
            Streamer Dashboard v1.0
          </span>
        </div>
        <h2 className="text-5xl font-black tracking-tighter leading-tight">
          Find the <span className="text-orange-500">Fire</span> in your Stream.
        </h2>
        <p className="text-slate-400 font-medium max-w-md mx-auto leading-relaxed">
          The lightweight timestamp collector for streamers and their viewers. Mark moments, export timecodes, ship faster.
        </p>
      </div>

      <div className="relative">
        <div className="absolute inset-0 bg-orange-600/5 blur-[80px] rounded-full scale-110 -z-10" />
        <form 
          onSubmit={handleCreateSession} 
          className="bg-slate-900/50 backdrop-blur-xl p-8 rounded-[2.5rem] border border-slate-800 shadow-2xl space-y-6"
        >
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-[10px] uppercase font-black text-slate-500 ml-1 tracking-widest">Session Title</label>
              <input
                type="text"
                placeholder="E.g., Subathon Day 1!"
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-5 py-3.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-orange-500/50 transition-all placeholder:text-slate-700"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <label className="text-[10px] uppercase font-black text-slate-500 ml-1 tracking-widest">Game / Category</label>
              <input
                type="text"
                placeholder="E.g., Valorant"
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-5 py-3.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-orange-500/50 transition-all placeholder:text-slate-700"
                value={game}
                onChange={(e) => setGame(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] uppercase font-black text-slate-500 ml-1 tracking-widest">Stream Start (Local Time)</label>
            <div className="flex gap-2">
              <input
                type="datetime-local"
                className="flex-grow bg-slate-950 border border-slate-800 rounded-2xl px-5 py-3.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-orange-500/50 transition-all text-slate-300"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                required
              />
              <button
                type="button"
                onClick={setTimeToNow}
                className="px-6 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-black tracking-widest uppercase transition-all border border-slate-700 active:scale-95"
              >
                Now
              </button>
            </div>
            <p className="text-[9px] text-slate-600 font-bold uppercase tracking-widest mt-1 ml-1">
              Sync this with your "Go Live" time for accurate VOD timestamps.
            </p>
          </div>

          <button
            type="submit"
            className="w-full bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-500 hover:to-red-500 text-white font-black py-4 rounded-2xl transition-all shadow-xl shadow-orange-900/20 active:scale-[0.98] transform uppercase tracking-[0.2em] text-sm"
          >
            Create Session Link
          </button>
        </form>
      </div>

      <div className="space-y-4">
        <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-600 text-center">Recent Sessions</h3>
        <div className="grid gap-3">
          {recentSessions.slice(0, 5).map((s) => (
            <div 
              key={s.id} 
              onClick={() => window.location.hash = `#/d/${s.id}`}
              className="group relative bg-slate-900/30 border border-slate-800/50 hover:border-orange-500/30 p-5 rounded-3xl cursor-pointer transition-all flex justify-between items-center pr-16"
            >
              <div className="flex items-center gap-4">
                <div className="w-8 h-8 rounded-xl bg-slate-800 flex items-center justify-center text-sm">📁</div>
                <div>
                  <p className="font-bold text-slate-200 group-hover:text-white transition-colors">{s.title}</p>
                  <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest">{s.game} • {new Date(s.createdAt).toLocaleDateString()}</p>
                </div>
              </div>
              <button 
                onClick={(e) => deleteSession(s.id, e)}
                className="absolute right-5 opacity-0 group-hover:opacity-100 p-2 hover:bg-red-500/10 rounded-lg text-slate-600 hover:text-red-500 transition-all"
                title="Delete Session"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
              </button>
            </div>
          ))}
          {recentSessions.length === 0 && (
            <div className="py-12 text-center bg-slate-900/10 rounded-[2rem] border border-dashed border-slate-800">
              <p className="text-slate-600 text-[10px] font-black uppercase tracking-[0.2em]">No sessions found.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Home;
