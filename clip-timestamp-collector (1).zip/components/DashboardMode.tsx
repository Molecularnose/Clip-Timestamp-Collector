
import React, { useState, useEffect } from 'react';
import { Session, TimestampMark } from '../types';

interface DashboardModeProps {
  sessionId: string;
}

const DashboardMode: React.FC<DashboardModeProps> = ({ sessionId }) => {
  const [session, setSession] = useState<Session | null>(null);
  const [marks, setMarks] = useState<TimestampMark[]>([]);
  const [showCopied, setShowCopied] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [lastMarkId, setLastMarkId] = useState<string | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const loadData = () => {
      const sessions: Session[] = JSON.parse(localStorage.getItem('cc_sessions') || '[]');
      const current = sessions.find(s => s.id === sessionId);
      if (current) setSession(current);

      const allMarks: TimestampMark[] = JSON.parse(localStorage.getItem('cc_marks') || '[]');
      const filtered = allMarks.filter(m => m.sessionId === sessionId);
      setMarks(filtered);
    };

    loadData();

    // Listen for viewer submissions from other tabs/users
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'cc_marks') {
        const allMarks: TimestampMark[] = JSON.parse(e.newValue || '[]');
        const filtered = allMarks.filter(m => m.sessionId === sessionId);
        
        // Simple heuristic to highlight new marks
        if (filtered.length > marks.length) {
          const sorted = [...filtered].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
          const newest = sorted[0];
          setLastMarkId(newest.id);
          setTimeout(() => setLastMarkId(null), 4000);
        }
        
        setMarks(filtered);
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [sessionId, marks.length]);

  const formatOffset = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h > 0 ? h + ':' : ''}${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const getLiveOffset = () => {
    if (!session) return "00:00:00";
    const start = new Date(session.startTime).getTime();
    const now = currentTime.getTime();
    const diff = Math.max(0, Math.floor((now - start) / 1000));
    return formatOffset(diff);
  };

  const handleToggleClipped = (id: string) => {
    const allMarks: TimestampMark[] = JSON.parse(localStorage.getItem('cc_marks') || '[]');
    const updated = allMarks.map(m => m.id === id ? { ...m, isClipped: !m.isClipped } : m);
    localStorage.setItem('cc_marks', JSON.stringify(updated));
    setMarks(updated.filter(m => m.sessionId === sessionId));
  };

  const exportCSV = () => {
    const headers = ['Timestamp', 'Seconds', 'Note', 'Submitted By', 'Status'];
    const sortedMarks = [...marks].sort((a, b) => a.offsetSeconds - b.offsetSeconds);
    const rows = sortedMarks.map(m => [
      formatOffset(m.offsetSeconds),
      m.offsetSeconds.toString(),
      `"${(m.note || 'Clip').replace(/"/g, '""')}"`,
      m.submittedBy || 'Anonymous',
      m.isClipped ? 'Clipped' : 'Pending'
    ]);
    const csvContent = "data:text/csv;charset=utf-8," + [headers, ...rows].map(e => e.join(",")).join("\n");
    const link = document.createElement("a");
    link.setAttribute("href", encodeURI(csvContent));
    link.setAttribute("download", `${session?.title || 'clips'}_timecodes.csv`);
    link.click();
  };

  const copyToClipboard = () => {
    const text = marks
      .sort((a, b) => a.offsetSeconds - b.offsetSeconds)
      .map(m => `[${formatOffset(m.offsetSeconds)}] ${m.note || 'Highlight'} - ${m.submittedBy || 'Anon'}`)
      .join('\n');
    navigator.clipboard.writeText(text);
    setShowCopied(true);
    setTimeout(() => setShowCopied(false), 2000);
  };

  const viewerLink = `${window.location.origin}${window.location.pathname}#/v/${sessionId}`;

  if (!session) return <div className="text-center p-20 animate-pulse text-slate-500 font-black uppercase tracking-widest">Searching for session...</div>;

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row gap-6">
        <div className="flex-grow bg-slate-900 border border-slate-800 p-8 rounded-[2.5rem] flex flex-col md:flex-row justify-between items-center gap-8 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4">
             <div className="flex items-center gap-2 px-3 py-1 bg-orange-500/10 rounded-full border border-orange-500/20">
               <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-ping" />
               <span className="text-[8px] font-black text-orange-500 uppercase tracking-widest">Live Pulse</span>
             </div>
          </div>

          <div className="space-y-1 text-center md:text-left z-10">
            <h2 className="text-3xl font-black tracking-tight">{session.title}</h2>
            <p className="text-slate-500 font-black uppercase text-xs tracking-widest">{session.game}</p>
          </div>
          
          <div className="flex items-center gap-8 border-l border-slate-800 pl-8 z-10">
            <div className="text-center">
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">VOD Offset Clock</p>
              <p className="text-4xl font-black font-mono text-orange-500 tracking-tighter tabular-nums drop-shadow-[0_0_15px_rgba(249,115,22,0.3)]">
                {getLiveOffset()}
              </p>
            </div>
          </div>
        </div>

        <div className="md:w-72 bg-slate-900 border border-slate-800 p-6 rounded-[2rem] flex flex-col justify-center gap-3">
          <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest text-center">Share Link with Viewers</label>
          <div className="flex items-center gap-2 bg-slate-950 p-2 rounded-xl border border-slate-800">
            <input readOnly value={viewerLink} className="bg-transparent text-[10px] text-slate-500 px-2 flex-grow focus:outline-none truncate font-mono" />
            <button 
              onClick={() => {
                navigator.clipboard.writeText(viewerLink);
                setShowCopied(true);
                setTimeout(() => setShowCopied(false), 2000);
              }}
              className="bg-orange-600 hover:bg-orange-500 text-white text-[10px] font-black px-4 py-2 rounded-lg transition-all active:scale-95 whitespace-nowrap"
            >
              {showCopied ? 'COPIED!' : 'COPY LINK'}
            </button>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:justify-between md:items-end px-2 gap-4">
          <div className="space-y-1">
            <h3 className="text-xs font-black uppercase tracking-[0.2em] text-slate-600">Marks Collected</h3>
            <p className="text-2xl font-black">{marks.length} <span className="text-slate-700">Moments Captured</span></p>
          </div>
          <div className="flex gap-3">
            <button 
              onClick={exportCSV}
              className="flex-grow md:flex-none bg-slate-100 hover:bg-white text-slate-900 text-[10px] font-black uppercase tracking-widest px-6 py-3.5 rounded-2xl transition-all shadow-xl shadow-white/5 active:scale-95 border border-transparent"
            >
              📊 Export CSV
            </button>
            <button 
              onClick={copyToClipboard}
              className="flex-grow md:flex-none bg-slate-800 hover:bg-slate-700 text-slate-100 text-[10px] font-black uppercase tracking-widest px-6 py-3.5 rounded-2xl transition-all active:scale-95 border border-slate-700"
            >
              📋 Copy Text
            </button>
          </div>
        </div>

        <div className="grid gap-3">
          {marks.sort((a, b) => b.offsetSeconds - a.offsetSeconds).map((m) => (
            <div 
              key={m.id} 
              className={`
                group flex flex-col md:flex-row items-center justify-between p-6 rounded-[2rem] border transition-all duration-300 gap-4
                ${m.id === lastMarkId ? 'border-orange-500 ring-4 ring-orange-500/20 scale-[1.01] bg-orange-500/5' : ''}
                ${m.isClipped 
                  ? 'bg-slate-950/40 border-slate-900 opacity-50 grayscale' 
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700 shadow-lg'
                }
              `}
            >
              <div className="flex flex-col md:flex-row items-center gap-4 md:gap-8 w-full">
                <div className="flex flex-col items-center justify-center min-w-[100px] bg-slate-950/50 py-2 px-4 rounded-2xl border border-slate-800/50">
                  <span className="text-2xl font-black text-orange-500 font-mono tracking-tighter tabular-nums">
                    {formatOffset(m.offsetSeconds)}
                  </span>
                </div>
                <div className="space-y-1 text-center md:text-left border-slate-800 md:pl-8 md:border-l">
                  <p className="font-bold text-slate-200 text-lg">
                    {m.note || 'Community Highlight'}
                  </p>
                  <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest">
                    By <span className="text-slate-400">{m.submittedBy}</span> • {new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
              
              <button
                onClick={() => handleToggleClipped(m.id)}
                className={`
                  w-full md:w-auto h-12 px-8 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all
                  ${m.isClipped 
                    ? 'bg-green-600/20 text-green-500 border border-green-500/30' 
                    : 'bg-slate-800 hover:bg-orange-600 text-slate-400 hover:text-white border border-slate-700 hover:border-orange-500'
                  }
                `}
              >
                {m.isClipped ? '✓ Saved' : 'Mark Saved'}
              </button>
            </div>
          ))}
          {marks.length === 0 && (
            <div className="py-24 text-center bg-slate-900/10 rounded-[3rem] border border-dashed border-slate-800">
              <div className="text-4xl mb-4">⌛</div>
              <p className="text-slate-700 text-[10px] font-black uppercase tracking-[0.3em]">Waiting for first mark...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DashboardMode;
