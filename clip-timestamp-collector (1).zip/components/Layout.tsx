
import React from 'react';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col items-center bg-slate-950 text-slate-100 selection:bg-orange-500/30">
      <header className="w-full max-w-4xl px-4 py-8 flex justify-between items-center border-b border-slate-800/50">
        <div 
          className="flex items-center gap-3 cursor-pointer group" 
          onClick={() => window.location.hash = ''}
        >
          <div className="w-10 h-10 bg-gradient-to-br from-orange-400 to-red-600 rounded-xl flex items-center justify-center shadow-lg shadow-orange-500/20 group-hover:scale-110 transition-transform">
            <span className="text-xl">🔥</span>
          </div>
          <h1 className="text-2xl font-black tracking-tighter bg-gradient-to-r from-orange-400 to-red-500 bg-clip-text text-transparent">
            CLIP COLLECTOR
          </h1>
        </div>
        <div className="flex flex-col items-end">
          <nav className="text-[10px] uppercase font-black tracking-[0.2em] text-slate-500 bg-slate-900 px-3 py-1 rounded-full border border-slate-800">
            MVP v1.0
          </nav>
        </div>
      </header>
      <main className="w-full max-w-4xl px-4 py-8 flex-grow">
        {children}
      </main>
      <footer className="w-full py-8 text-center border-t border-slate-900/50">
        <p className="text-slate-600 text-[11px] font-bold uppercase tracking-widest">
          Built for the Gaming Community
        </p>
      </footer>
    </div>
  );
};

export default Layout;
