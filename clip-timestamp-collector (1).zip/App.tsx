
import React, { useState, useEffect } from 'react';
import { AppRoute, Session, TimestampMark } from './types';
import Home from './components/Home';
import ViewerMode from './components/ViewerMode';
import DashboardMode from './components/DashboardMode';
import Layout from './components/Layout';

const App: React.FC = () => {
  const [route, setRoute] = useState<AppRoute>(AppRoute.HOME);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);

  // Simple Hash Routing logic
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      if (hash.startsWith('#/v/')) {
        const id = hash.replace('#/v/', '');
        setCurrentSessionId(id);
        setRoute(AppRoute.VIEWER);
      } else if (hash.startsWith('#/d/')) {
        const id = hash.replace('#/d/', '');
        setCurrentSessionId(id);
        setRoute(AppRoute.DASHBOARD);
      } else {
        setRoute(AppRoute.HOME);
        setCurrentSessionId(null);
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange(); // Initial check

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const renderContent = () => {
    switch (route) {
      case AppRoute.VIEWER:
        return currentSessionId ? <ViewerMode sessionId={currentSessionId} /> : <Home />;
      case AppRoute.DASHBOARD:
        return currentSessionId ? <DashboardMode sessionId={currentSessionId} /> : <Home />;
      case AppRoute.HOME:
      default:
        return <Home />;
    }
  };

  return (
    <Layout>
      {renderContent()}
    </Layout>
  );
};

export default App;
