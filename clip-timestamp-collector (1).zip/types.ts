
export interface Session {
  id: string;
  title: string;
  game: string;
  startTime: string; // ISO string of the stream start
  createdAt: string; // ISO string
}

export interface TimestampMark {
  id: string;
  sessionId: string;
  offsetSeconds: number; // Seconds since session.startTime
  note: string;
  submittedBy?: string;
  isClipped: boolean;
  createdAt: string; // ISO string
}

export enum AppRoute {
  HOME = 'HOME',
  VIEWER = 'VIEWER',
  DASHBOARD = 'DASHBOARD'
}
